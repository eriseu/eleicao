import { cache } from 'react';
import { unstable_cache } from 'next/cache';
import { S3Client, GetObjectCommand } from '@aws-sdk/client-s3';
import { gunzipSync } from 'node:zlib';
import { AVAILABLE_UFS } from '@/constants/elections';
import { safeJsonParse } from '@/lib/robustJson';

export const SITEMAP_PAGE_SIZE = 10000;

export function xmlEscape(str: string): string {
  return str
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&apos;');
}

// Inicializa o cliente do R2 com autenticação de chaves (Zero CORS / Zero WAF)
const r2 = new S3Client({
  region: 'auto',
  endpoint: process.env.R2_ENDPOINT,
  credentials: {
    accessKeyId: process.env.R2_ACCESS_KEY_ID || '',
    secretAccessKey: process.env.R2_SECRET_ACCESS_KEY || '',
  },
});

const BUCKET_NAME = process.env.R2_BUCKET || 'eleicao';

function normalizeCandidateIds(items: unknown[]): string[] {
  if (!Array.isArray(items)) return [];

  const ids = items
    .map((item) => {
      if (typeof item === 'string') return item.trim();
      if (typeof item === 'number') return String(item).trim();
      if (item && typeof item === 'object') {
        const candidate = item as Record<string, unknown>;
        if (typeof candidate.id === 'string' && candidate.id.trim()) {
          return candidate.id.trim();
        }
        if (candidate.sq_candidato) {
          return String(candidate.sq_candidato).trim();
        }
      }
      return null;
    })
    .filter((id): id is string => Boolean(id));

  return Array.from(new Set(ids.filter(id => /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(id)).map(id => id.toLowerCase())));
}

export async function getCandidateIdsForUf(uf: string): Promise<string[]> {
  const objectKey = `candidatos-ids/${uf.toUpperCase()}.json`;

  try {
    const command = new GetObjectCommand({
      Bucket: BUCKET_NAME,
      Key: objectKey,
    });

    const response = await r2.send(command);
    const chunks: Uint8Array[] = [];

    for await (const chunk of response.Body as AsyncIterable<Uint8Array>) {
      chunks.push(Buffer.isBuffer(chunk) ? chunk : Buffer.from(chunk));
    }

    const rawBytes = Buffer.concat(chunks);
    if (!rawBytes.length) {
      throw new Error(`O arquivo '${objectKey}' veio vazio do R2.`);
    }

    const decoded = response.ContentEncoding === 'gzip' ? gunzipSync(rawBytes) : rawBytes;
    const bodyContents = decoded.toString('utf8');

    const data = safeJsonParse(bodyContents);

    if (!Array.isArray(data)) {
      throw new Error(`JSON retornado em '${objectKey}' não é uma lista válida.`);
    }

    return normalizeCandidateIds(data);
  } catch (error: any) {
    const errorMsg = `Erro ao ler '${objectKey}' via R2 SDK: ${error?.message || error}`;
    console.error(`[SITEMAP SDK ERROR] ${errorMsg}`);
    throw new Error(errorMsg);
  }
}

export const getAllCandidateIdsFromR2 = cache(async (): Promise<string[]> => {
  try {
    const results = await Promise.all(AVAILABLE_UFS.map((uf) => getCandidateIdsForUf(uf)));
    return normalizeCandidateIds(results.flat());
  } catch {
    return [];
  }
});

export async function getSitemapCandidateCount(): Promise<number> {
  const ids = await getAllCandidateIdsFromR2();
  return ids.length;
}

export async function getSitemapPageCountForUf(uf: string): Promise<number> {
  const ids = await getCandidateIdsForUf(uf);
  return Math.max(0, Math.ceil(ids.length / SITEMAP_PAGE_SIZE));
}

export async function getSitemapCandidatePage(page: number, uf?: string) {
  const allIds = uf ? await getCandidateIdsForUf(uf) : await getAllCandidateIdsFromR2();
  const start = page * SITEMAP_PAGE_SIZE;
  const end = start + SITEMAP_PAGE_SIZE;
  return allIds.slice(start, end);
}

// This app has not enabled Cache Components. Cache only the small manifest,
// not the multi-megabyte state datasets, using the supported compatibility API.
export const getSitemapManifest = unstable_cache(async () => {
  const entries: { uf: string; pages: number }[] = [];
  for (let start = 0; start < AVAILABLE_UFS.length; start += 4) {
    const batch = await Promise.all(AVAILABLE_UFS.slice(start, start + 4).map(async uf => ({
      uf: uf.toLowerCase(), pages: await getSitemapPageCountForUf(uf),
    })));
    entries.push(...batch);
  }
  return entries;
}, ['sitemap-manifest-v2'], { revalidate: 86400 });
